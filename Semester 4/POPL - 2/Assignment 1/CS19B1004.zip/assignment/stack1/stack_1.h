#ifndef STACK_H
#define STACK_H

typedef long long stack_id;
void create_stack(long long,long long);
void destroy_stack();
void push(stack_id,long long, long long);
void pop(stack_id); 
void print(stack_id,long long);

#endif