#include <iostream>
#include <cstdlib>
#include "stack_1.h"
//method 2
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating a global array of size m*n
        create_stack(m,n);
        
        i=0;
        while(i<n){
                cin >> p >> s;
                //push operation
                if(s=="push"){
                        cin >> q;
                        push(p-1,q,n);
                }
                //pop operation
                else if(s=="pop"){
                        pop(p-1);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                print(i,n);
        }
//destroying the global array        
        destroy_stack();
        return 0;
}