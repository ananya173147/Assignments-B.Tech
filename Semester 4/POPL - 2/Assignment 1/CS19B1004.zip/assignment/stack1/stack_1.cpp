#include <iostream>
#include <cstdlib>
#include "stack_1.h"

using namespace std;

//global array to store the current index values of the stack
stack_id *indices;
//global array to store the actual values of the stack
long long *arr;

//creating and initializing the global arrays
void create_stack(long long m,long long n){
        arr = new long long[m*n];
        indices = new stack_id[m];
        for(long long i=0;i<m;i++){
                indices[i] = -1;
        }
}

//push operation
void push(stack_id id, long long value, long long n) {
        indices[id]++;
        arr[id*n+indices[id]] = value;
    
} 

//pop operation
void pop(stack_id id) { 
        if(indices[id]==-1)
                return;
        indices[id]--;
} 

//print operation
void print(stack_id id,long long n){
        for(long long i=indices[id];i>=0;i--){
                cout << arr[id*n+i] << " ";
        }
        cout << endl;
}

//destroy operation
void destroy_stack(){
        delete indices;
        delete arr;
}