#include <iostream>
#include <cstdlib>
#include "stack_10.h"
//method 11

using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;

        stack stacks[m];

        for(i=0;i<m;i++){
                stacks[i] = stack(n);
        }
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stacks[p-1].push(q);
                }
                else if(s=="pop"){
                        stacks[p-1].pop();
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                stacks[i].print();
                cout << endl;
        }

        return 0;
}