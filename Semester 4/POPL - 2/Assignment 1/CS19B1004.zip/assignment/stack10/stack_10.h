#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

class stack {
//struct to represent stack data members
        struct rep{
                long long* array;
                long long index;
                long long size;
        };
        rep* p;

public: 
//stack operations
        stack(){};
        stack(long long s);
        void push(long long value);
        void pop();
        void print();
        ~stack(){};
};

#endif