#include <iostream>
#include <cstdlib>
#include "stack_10.h"

using namespace std;
//creating and initialising stack data members present in struct rep
stack::stack(long long s){
        stack::rep* srep = (stack::rep*)malloc(sizeof(stack::rep)); 
        this->p = srep;
        this->p->index = -1;
        this->p->size = s;
        this->p->array = (long long*)malloc(sizeof(long long)*s);
};

//push operation
void stack::push(long long value){
        if(this->p->index!=this->p->size){
                this->p->index++;
                this->p->array[this->p->index] = value;
        }
};

//pop operation
void stack::pop(){
        if(this->p->index!=-1){
                this->p->index--;
        }
}

//print operation
void stack::print(){
        for(int i=this->p->index;i>=0;i--){
                cout << this->p->array[i] << " ";
        }
        free(this->p);
}
