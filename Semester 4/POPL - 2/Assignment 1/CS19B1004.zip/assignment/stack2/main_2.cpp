#include <iostream>
#include <cstdlib>
#include "stack_2.h"
//method 3
using namespace std;

int main(){
        long long m,n,i,q;
        stack_id p;
        string s;
        cin >> m >> n;
        //creating and initialising global array of size n*m
        create_stack(m,n);
        i=0;
        //push and pop operations
        while(i<n){
                cin >> p.s_id >> s;
                if(s=="push"){
                        cin >> q;
                        push(p,q,n);
                }
                else if(s=="pop"){
                        pop(p);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                print(i,n);
        }
        destroy_stack();
        return 0;
}