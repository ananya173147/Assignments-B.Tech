#ifndef STACK_H
#define STACK_H

//making the stack_ids a genuine type
struct stack_id{ 
        long long s_id;
};
void create_stack(long long,long long);
void destroy_stack();
void push(stack_id,long long, long long);
void pop(stack_id); 
void print(long long,long long);

#endif