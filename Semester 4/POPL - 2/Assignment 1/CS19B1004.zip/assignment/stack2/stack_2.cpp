#include <iostream>
#include <cstdlib>
#include "stack_2.h"
using namespace std;

//global array to store the current index values of the stack
stack_id *indices;
//global array to store the actual values of the stack
long long *arr;

void create_stack(long long m,long long n){
        arr = new long long[m*n];
        indices = new stack_id[m];
        for(long long i=0;i<m;i++){
                indices[i].s_id = -1;
        }
}

void push(stack_id id, long long value, long long n) {
        id.s_id--;
        indices[id.s_id].s_id++;
        arr[id.s_id*n+indices[id.s_id].s_id] = value;
    
} 
   
void pop(stack_id id) { 
        id.s_id--;
        if(indices[id.s_id].s_id==-1)
                return;
        indices[id.s_id].s_id--;
} 

void print(long long id,long long n){
        for(long long i=indices[id].s_id;i>=0;i--){
                cout << arr[id*n+i] << " ";
        }
        cout << endl;
}

void destroy_stack(){
        delete indices;
        delete arr;
}