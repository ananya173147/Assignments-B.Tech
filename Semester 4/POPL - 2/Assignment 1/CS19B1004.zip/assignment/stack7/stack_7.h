#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

//placing representation globally to minimize recompilatino costs
class stack_rep{
public:
        long long index;
        long long size;
        long long* arr;
        stack_rep(long long);
};

class stack{
public:
        typedef stack_rep* id;
        static id create_stack(long long);
        static void destroy(id);
        static void push(id,long long);
        static void pop(id);
        static void print(id);
private:
        virtual void dummy() = 0;
};

#endif