#include <iostream>
#include <cstdlib>
#include "stack_7.h"
//method 8 
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating and initialising stack data members
        stack_rep* stack_array[m];

        for(i=0;i<m;i++){
                stack_array[i] = stack::create_stack(n);
        }
//stack operations
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stack::push(stack_array[p-1],q);
                }
                else if(s=="pop"){
                        stack::pop(stack_array[p-1]);
                }
                i++;   
        }
//printing stacks
        for(i=0;i<m;i++){
                cout << i+1 << " ";
                for(j=stack_array[i]->index;j>=0;j--){
                        cout << stack_array[i]->arr[j] << " "; 
                } 
                cout << endl;
        }

        return 0;
}