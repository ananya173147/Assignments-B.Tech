#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

//struct to represent stack 
typedef struct stack{
        long long index;
        long long size;
        long long* arr;
}stack;

//stack operations
stack* create_stack(long long);
void push(stack*, long long);
void pop(stack*, long long);

#endif