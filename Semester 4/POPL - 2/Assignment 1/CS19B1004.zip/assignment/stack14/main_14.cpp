#include <iostream>
#include <cstdlib>
#include "stack_14.h"

using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//array of pointers to stacks
        stack* stack_array[m];
//creating and initialising stack data members
        for(i=0;i<m;i++){
                stack_array[i] = create_stack(n);
        }
//an array of function pointers pointing to stack operations
        void (*fun_ptr_arr[])(stack* id, long long) = {push, pop};

        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        (*fun_ptr_arr[0])(stack_array[p-1], q); 
                }
                else if(s=="pop"){
                        (*fun_ptr_arr[1])(stack_array[p-1], p); 
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                for(j=stack_array[i]->index;j>=0;j--){
                        cout << stack_array[i]->arr[j] << " "; 
                } 
                cout << endl;
        }

        return 0;
}