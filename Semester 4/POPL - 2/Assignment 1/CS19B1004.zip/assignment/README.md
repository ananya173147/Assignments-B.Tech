## README

> Ananya Mantravadi
> CS19B1004

### Compiling and generating binary files
Run `make` in the terminal to run the Makefile which generates bin folder which contains the binary files.

Run `make clean` to remove all the bin folder and and binary files generated

### Running 
Type the following command after including the textfile "inp.txt" which contains the test cases: 
`./bin/stack0<inp.txt`

### Stack 0
Implementing a stack using struct, which contains an array that is dynamically allocated memory accorded to the number of total operations which is given in the first line of input by the user. Multiple stacks have been kept track of by using an array of pointers to the addresses of these stacks. This implementation is imperative (only C).

### Stack 1
This implementation uses stack_ids which are passed into functions that perform push and pull operations. There is global array declared which holds m stacks with capacity n, giving the size of the global array m*n. This technique relies on the convention of .h files and on comments to express the concept of a stack.

### Stack 2
We improve the above implementation by making the stack_ids a genuine type, with a struct type to hold the stack_id, which will prevent us from accidentally mixing up stack identifiers and long long integers. This and the former versions both have the nice property that the implementation is completely hidden so that it can be changed without requiring recompilation of user code as long as the interface remains unchanged.

### Stack 3
We use a class to specify this stack module that use static member functions, indicating that the member functions do not operate on
specific objects of class stack; rather, class stack is only used to provide a name space for stack operations. 

### Stack 4
To prevent declaration of object of stack, we make it an abstract class with the definition of a pure virtual function. Also by using `friend stack` within class id of class stack, the representation of an id is now accessible only to class stack.

### Stack 5
We now implement that allows us to pass around objects themselves or pointers to them. The representation of stacks is placed in the declaration of class stack. We also add explicit initialization, cleanup functions, and enable compiler to make inlining of such operations.

### Stack 6
In the above implementation if we did not want users to allocate representations directly we could control the creation and copying of reps by making these operations private. Thus, only the stack functions can create these representations.

### Stack 7
If we are not interested in inlining but prefer to minimize recompilation costs, we can place the representation outside, declared globally. This scheme keeps implementation details not only inaccessible to users but also out of sight.

### Stack 8
Improving the former implementation, we would put the operations that create and destroy stack representations into class stack. The representation will be declared privately in this class stack.

### Stack 9
From this implementation on, we make all functions non-static and give the constructor and destructor their proper names. Functions are called in the usual C++ member access notation.

### Stack 10
If we want the ability to change the representation of a stack without forcing the recompilation of users of a stack we must reintroduce a representation class re pand let stack objects hold only pointers to reps. This indirection is invisible to the user.

### Stack 11
We can implement different representations of stack with a common user interface. Base class stack will be abstract, holding virtual functions which can be overidden by the derived astack and lstack classes which contain array and linked list implementations respectively. I have created a program that takes first half of the input stacks in array representation and the rest in linked list representation.

### Stack 12
Through this implementation we can change both the representation and operations for an object at run time. To ensure that the cutover from one representation to another can be done by a single assignment we reintroduce the reptype and make operations simple forwarding functions to operations on the rep. The function `convert_from_l_to_a` takes any stack as input and converts it into astack*.

### Stack 13
This implementation uses the templates feature in C++. To support a vector of stacks, an abstract parent class contains the derived stack class. For this program I have defined the template type to be long long.

### Stack 14
This implementation shows the usage function pointers in C++. An array of pointers stores the addresses of these stacks, and depending on the operation, push or pop, the respective function is called using an array of function pointers.

### Stack 15
This implementation dispenses with static type checking of the operations. The idea is to completely disconnect the users and the implementers and simulate a dynamically type-checked language. This also allows to add stack operations during runtime.




