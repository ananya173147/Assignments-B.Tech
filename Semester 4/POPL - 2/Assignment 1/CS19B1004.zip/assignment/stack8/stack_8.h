#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

//putting operations that create and destroy stack representations into class stack
class stack{
        long long index;
        long long size;
        long long* arr;
public:
        stack(long long);
        typedef stack* id;
        static id create_stack(long long);
        static void destroy(id);
        static void push(id,long long);
        static void pop(id);
        static void print(id);
};

#endif