#include <iostream>
#include <cstdlib>
#include "stack_8.h"

using namespace std;
//stack operations
stack::stack(long long s){
        index = -1;
        size = s;
        arr = (long long*)malloc(sizeof(long long)*size);
}

stack::id stack::create_stack(long long size){
        stack* new_stack = new stack(size);
        return new_stack;
}

void stack::destroy(id no){
        free(no);
}

void stack::push(id no, long long value){
        if(no->index!=no->size){
                no->index++;
                no->arr[no->index] = value;
        }

}

void stack::pop(id no){
        long long value;
        if(no->index!=-1){
                value = no->arr[no->index];
                no->index--;
        }
}

void stack::print(id no){
        for(long long j=no->index;j>=0;j--){
                        cout << no->arr[j] << " "; 
        } 
        cout << endl;
}