#include "stack_12.h"
//array representation of stack derived from base rep class
class astack: public rep{
        long long* array;
        long long index;
        long long maxsize;
        
public:
//stack operations
        astack(){};
        astack(long long s);
        ~astack(){}; 
        void push(long long value);
        long long pop();
        long long size();
        void print();
};