class rep{
//base rep class from which astack and lstack are derived
public:
        virtual void push(long long value) = 0;
        virtual long long pop() = 0;
        virtual long long size() = 0;
        
};