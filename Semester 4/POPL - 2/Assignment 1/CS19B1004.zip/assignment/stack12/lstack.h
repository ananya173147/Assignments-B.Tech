#include "stack_12.h"
//linked list representation of stack derived from base rep class
class lstack: public rep{
        struct node {
	        long long data;
	        struct node* next;
        }; 
        struct node* head;
        long long maxsize;
        long long curr_size;
        node* n;

public:
//stack operations
        lstack(){};
        lstack(long long s);
        ~lstack(){} ;
        void push(long long value);
        long long pop();
        long long size();
        void print();
};