#include <iostream>
#include <cstdlib>
#include "stack_12.h"
#include "astack.h"
#include "lstack.h"

//method 14

using namespace std;

//return the size of astack
long long astack::size(){
        return this->index;
}
//return the size of lstack
long long lstack::size(){
        return this->curr_size;
}

//creating and initialising stack data members
astack::astack(long long s){
        this->index = -1;
        this->maxsize = s;
        this->array = (long long*)malloc(sizeof(long long)*maxsize);
};

lstack::lstack(long long s){
        this->maxsize = s;
        this->curr_size = 0;
        this->head = NULL;
}

//stack operations
void astack::push(long long value){
        if(this->index!=this->maxsize){
                this->index++;
                this->array[index] = value;
        }
};

void lstack::push(long long value){
        node* new_node = (node*)malloc(sizeof(node)); 
        new_node->data = value;
        new_node->next = this->head;
        this->head = new_node;
        this->curr_size++;
};

long long astack::pop(){
        if(this->index!=-1){
                this->index--;
                return this->array[this->index+1];
        }
        else
                return -1;
};

long long lstack::pop(){
        if(this->head!=NULL){
                node* temp = this->head;
                this->head = this->head->next;
                long long value = temp->data;
                this->curr_size--;
                free(temp);
                return value;
        }
        else 
                return -1;
};

void astack::print(){
        for(int i=this->index;i>=0;i--){
                cout << this->array[i] << " ";
        }
        cout << endl;
        free(this->array);
}

void lstack::print(){
        if(this->head==NULL){
                cout << endl;
                return;
        }
        node* curr = this->head;
        node* temp;
        while(curr!=NULL){
                cout << curr->data << " ";
                temp = curr->next;
                free(curr);
                curr=temp;
        }
        cout << endl;
}
