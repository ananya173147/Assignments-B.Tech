#ifndef STACK_H
#define STACK_H
#include "rep.h"

class stack{
//pointer to rep abstract class
        rep* p;
public:
//stack operations
        stack(){};
        stack(long long size);
        rep* get_rep(){
                return p; 
        }
        void put_rep(rep* q) {
                p = q; 
        }
        void push(long long c) { 
                p->push(c); 
        }
        long long pop() {
                return p->pop(); 
        }
        long long size() { 
                return p->size(); 
        }
        
        ~stack(){};
};

#endif