#include <iostream>
#include <cstdlib>
#include "stack_9.h"
//method 10
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating and initialising stack data members
        stack stacks[m];

        for(i=0;i<m;i++){
                stacks[i] = stack(n);
        }
//stack operations
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stacks[p-1].push(q);
                }
                else if(s=="pop"){
                        stacks[p-1].pop();
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                for(j=stacks[i].index;j>=0;j--){
                        cout << stacks[i].array[j] << " "; 
                } 
                cout << endl;
        }
        
        return 0;
}