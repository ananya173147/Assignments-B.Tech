#include <iostream>
#include <cstdlib>
#include "stack_9.h"

using namespace std;
//stack operations
stack::stack(long long s){
        index = -1;
        size = s;
        array = (long long*)malloc(sizeof(long long)*size);
};

void stack::push(long long value){
        if(index!=size){
                index++;
                array[index] = value;
        }
};

void stack::pop(){
        if(index!=-1){
                index--;
        }
}