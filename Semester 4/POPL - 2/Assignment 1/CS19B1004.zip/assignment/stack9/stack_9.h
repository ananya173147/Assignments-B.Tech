#ifndef STACK_H
#define STACK_H

//making  all functions non static 
class stack {

public: 
        long long* array;
        long long index;
        long long size;

        stack(){};
        stack(long long s);
        void push(long long value);
        void pop();
        ~stack(){};
};

#endif