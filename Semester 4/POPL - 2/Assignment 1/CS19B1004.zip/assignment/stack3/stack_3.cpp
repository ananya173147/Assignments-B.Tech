#include <iostream>
#include <cstdlib>
#include "stack_3.h"

using namespace std;
//stack operations
stack* stack::create_stack(long long size){
        stack* new_stack;
        new_stack = (stack*)malloc(sizeof(stack)); 
        new_stack->index = -1;
        new_stack->size = size;
        new_stack->arr = (long long*)malloc(sizeof(long long)*size);
        return new_stack;
}

void stack::push(stack* id, long long value){
        if(id->index!=id->size){
                id->index++;
                id->arr[id->index] = value;
        }

}

void stack::pop(stack* id){
        if(id->index!=-1){
                id->index--;
        }
}

void stack::destroy(stack* id){
        free(id);
}