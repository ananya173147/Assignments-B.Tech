#include <iostream>
#include <cstdlib>
#include "stack_3.h"
//method 4 
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating and initialising stack data members
        stack* stack_array[m];

        for(i=0;i<m;i++){
                stack_array[i] = stack::create_stack(n);
        }

        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stack::push(stack_array[p-1],q);
                }
                else if(s=="pop"){
                        stack::pop(stack_array[p-1]);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                for(j=stack_array[i]->index;j>=0;j--){
                        cout << stack_array[i]->arr[j] << " "; 
                }
                stack::destroy(stack_array[i]); 
                cout << endl;
        }

        return 0;
}