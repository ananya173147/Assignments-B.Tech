#ifndef STACK_H
#define STACK_H
//stack interface, stack.h
class stack {
        
public: 
        long long index;
        long long size;
        long long* arr;
        stack(){};
        static stack* create_stack(long long);
        static void push(stack*, long long);
        static void pop(stack*);
        static void destroy(stack*);
        ~stack(){};
};

#endif