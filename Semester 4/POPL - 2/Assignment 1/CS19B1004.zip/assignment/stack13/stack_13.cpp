#include <iostream>
#include <cstdlib>
#include "stack_13.h"

using namespace std;

// constructor to initialize the stack
template <class X>
stack<X>::stack(X s){       
        arr = (X*)malloc(sizeof(X)*s);
        size = s;
        index = -1;
}
 
//push operation
template <class X>
void stack<X>::push(X value)
{
        if(index==size)
                return;
        index = index + 1;
        arr[index] = value;
}
 
//pop operation
template <class X>
void stack<X>::pop()
{
        if(index==-1)
                return;
        index = index-1;
}
 
//printing stack
template <class X>
void stack<X>::print()
{
        for(long long j=index;j>=0;j--){
                        cout << arr[j] << " "; 
        } 
        cout << endl;
}

//defining which values the template accepts, in this case long long
template class stack<long long>;