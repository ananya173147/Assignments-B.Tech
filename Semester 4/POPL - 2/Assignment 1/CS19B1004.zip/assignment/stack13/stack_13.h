#ifndef STACK_H
#define STACK_H

class Base {
//defining a base class to enable vector to contain template objects
public:
        virtual void push(long long) = 0;
        virtual void pop() = 0;
        virtual void print() = 0;
        virtual ~Base() {};
};
// A class to represent a stack derived from Base class
template <class X>
class stack : public Base{
        long long index;
        long long size;
        X *arr;
public:
        stack();
        stack(X);        
        void push(X);
        void pop();
        void print(); 
        ~stack() {        /
                delete[] arr;
        }
};


#endif