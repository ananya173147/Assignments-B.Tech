#include <iostream>
#include <cstdlib>
#include <vector>
#include "stack_13.h"
//stack implementation using template
using namespace std;

int main(){

        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating a vector of template objects
        std::vector<Base*> array;

        for(i=0;i<m;i++){
        ////creating and initialising stack data members
                array.push_back(new stack<long long>(n));
        }

        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        //push operation
                        array[p-1]->push(q);
                }
                else if(s=="pop"){
                        //pop operation
                        array[p-1]->pop();
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                array[i]->print();
        }
       
        return 0;
}