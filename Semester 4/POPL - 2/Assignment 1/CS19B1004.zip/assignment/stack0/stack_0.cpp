#include <iostream>
#include <cstdlib>
#include "stack_0.h"

using namespace std;

//creating stack and initializing
stack* create_stack(long long size){
        stack* new_stack;
        new_stack = (stack*)malloc(sizeof(stack)); 
        new_stack->index = -1;
        new_stack->size = size;
        new_stack->arr = (long long*)malloc(sizeof(long long)*size);
        return new_stack;
}

//push operation
void push(stack* id, long long value){
        if(id->index!=id->size){
                id->index++;
                id->arr[id->index] = value;
        }

}

//pop operation
void pop(stack* id){
        long long value;
        if(id->index!=-1){
                value = id->arr[id->index];
                id->index--;
        }
}