#include <iostream>
#include <cstdlib>
#include "stack_0.h"

using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//array of pointers to stacks
        stack* stack_array[m];

        for(i=0;i<m;i++){
                stack_array[i] = create_stack(n);
        }

        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
//push operation                        
                        push(stack_array[p-1],q);
                }
//pop operation                
                else if(s=="pop"){
                        pop(stack_array[p-1]);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                //printing stacks
                for(j=stack_array[i]->index;j>=0;j--){
                        cout << stack_array[i]->arr[j] << " "; 
                } 
                cout << endl;
        }

        return 0;
}