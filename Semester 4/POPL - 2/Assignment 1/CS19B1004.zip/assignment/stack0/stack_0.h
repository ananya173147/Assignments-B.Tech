#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

typedef struct stack{
        long long index;
        long long size;
        long long* arr;
}stack;

stack* create_stack(long long size);
void push(stack* id, long long value);
void pop(stack* id);

#endif