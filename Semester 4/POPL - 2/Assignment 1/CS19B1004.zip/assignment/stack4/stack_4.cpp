#include <iostream>
#include <cstdlib>
#include "stack_4.h"

using namespace std;
//stack operations
stack::id* stack::create_stack(long long size){
        stack::id* new_s;
        new_s = (stack::id*)malloc(sizeof(stack::id)); 
        new_s->index = -1;
        new_s->size = size;
        new_s->arr = (long long*)malloc(sizeof(long long)*size);
        return new_s;
}

void stack::push(stack::id* id, long long value){

        if(id->index!=id->size){
                id->index++;
                id->arr[id->index] = value;
        }

}

void stack::pop(stack::id* id){
        long long value;
        if(id->index!=-1){
                value = id->arr[id->index];
                id->index--;
        }
}

void stack::print(stack::id* id){
        for(long long j=id->index;j>=0;j--){
                        cout << id->arr[j] << " "; 
        } 
        cout << endl;
}

void stack::destroy(stack::id* id){
        free(id);
}