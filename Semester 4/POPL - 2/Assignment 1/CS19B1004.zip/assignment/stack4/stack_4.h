#ifndef STACK_H
#define STACK_H

class stack{
//using friend stack within class id of class stack, the representation of an id is now accessible only to class stack
public:
        class id{
                friend stack;
        private:
                long long index;
                long long size;
                long long* arr;
        };
        static id* create_stack(long long s);
        static void push(stack::id*,long long value) ;
        static void pop(stack::id*);
        static void print(stack::id*);
        static void destroy(stack::id*);

private:
        virtual void dummy() = 0;
};

#endif