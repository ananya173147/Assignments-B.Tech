#include <iostream>
#include <cstdlib>
#include "stack_4.h"
//method 5 
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;

        stack::id* stack_array[m];

        //stack x; error-> object of abstract class type "stack" is not allowed: -- function "stack::dummy" is a pure virtual function

        for(i=0;i<m;i++){
                stack_array[i] = stack::create_stack(n);
        }

        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stack::push(stack_array[p-1],q);
                }
                else if(s=="pop"){
                        stack::pop(stack_array[p-1]);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                stack::print(stack_array[i]);
                stack::destroy(stack_array[i]);
        }

        return 0;
}