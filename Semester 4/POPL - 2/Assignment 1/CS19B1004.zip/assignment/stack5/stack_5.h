#ifndef STACK_H
#define STACK_H

class stack{

public:
        class rep{
                friend stack;
        private:
                long long index;
                long long size;
                long long* arr;
        };

        static rep* create_stack(long long s);
        static void destroy(rep& t);
        static void initialize(rep& t,long long s);
        static void cleanup(rep& t);
        static void push(rep& t,long long value) ;
        static void pop(rep& t);
        static void print(rep& t);

private:
        virtual void dummy() = 0;
};

#endif