#ifndef STACK_H
#define STACK_H

class stack{
//making operations private so that only stack can create representations
public:
        class rep{
                friend stack;
        private:
                long long index;
                long long size;
                long long* arr;
        rep(long long t);                                      // constructor
        rep(const rep& t);                                     // copy constructor
        void operator = (const rep& t);                        // assignment operator
        };

        static rep* create_stack(long long s);
        static void destroy(rep& t);
        static void initialize(rep& t,long long s);
        static void cleanup(rep& t);
        static void push(rep& t,long long value) ;
        static void pop(rep& t);
        static void print(rep& t);

private:
        virtual void dummy() = 0;
};

#endif