#include <iostream>
#include <cstdlib>
#include "stack_6.h"
//method 7 
using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
        //stack::rep s(10); -> error: cannot access rep::rep() - private member

        //creating and initialising stack data members with rep
        stack::rep* stack_array[m];

        for(i=0;i<m;i++){
                stack_array[i] = stack::create_stack(n);
                stack::initialize(*stack_array[i],n);
        }
//stack operations
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stack::push(*stack_array[p-1],q);
                }
                else if(s=="pop"){
                        stack::pop(*stack_array[p-1]);
                }
                i++;   
        }
//printing, cleaning up and destroying stacks
        for(i=0;i<m;i++){
                cout << i+1 << " ";
                stack::print(*stack_array[i]);
                stack::cleanup(*stack_array[i]);
                stack::destroy(*stack_array[i]);
        }

        return 0;
}