#include <iostream>
#include <cstdlib>
#include "stack_6.h"

using namespace std;
//stack operations
stack::rep* stack::create_stack(long long size){
        rep* new_s;
        new_s = (stack::rep*)malloc(sizeof(stack::rep)); 
        return new_s;
}

void stack::initialize(stack::rep &rep, long long s){
        rep.index = -1;
        rep.size = s;
        rep.arr = (long long*)malloc(sizeof(long long)*s);
}

void stack::cleanup(stack::rep &rep){
        free(rep.arr);
}

void stack::destroy(stack::rep &rep){
        free(&rep);
}

void stack::push(stack::rep &rep, long long value){

        if(rep.index!=rep.size){
                rep.index++;
                rep.arr[rep.index] = value;
        }

}

void stack::pop(stack::rep &rep){
        long long value;
        if(rep.index!=-1){
                value = rep.arr[rep.index];
                rep.index--;
        }
}

void stack::print(stack::rep &rep){
        for(long long j=rep.index;j>=0;j--){
                        cout << rep.arr[j] << " "; 
        } 
        cout << endl;
}