#include <iostream>
#include <cstdlib>
#include "stack_11.h"
#include "astack.h"
#include "lstack.h"
//method 12

using namespace std;

int main(){
        long long m,n,i,j,p,q;
        string s;
        cin >> m >> n;
//creating half the stacks with array representation
        astack astacks[m/2];
//creating rest of the stacks with linked list representation
        lstack lstacks[m-m/2];

        for(i=0;i<m/2;i++){
        //initialising stack data members of array
                astacks[i] = astack(n);
        }
        for(i=0;i<m-m/2;i++){
        //initialising stack data members of linked list
                lstacks[i] = lstack(n);
        }
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        if(p-1<m/2)
                        //push operation of astack
                                astacks[p-1].push(q);
                        else
                        //push operation of lstack
                                lstacks[p-m+m/2].push(q);
                }
                else if(s=="pop"){
                        if(p-1<m/2)
                        //pop operation of astack
                                astacks[p-1].pop();
                        else    
                        //pop operation of lstack
                                lstacks[p-m+m/2].pop();
                }
                i++;   
        }
//printing stacks
        for(i=0;i<m/2;i++){
                cout << i+1 << " ";
                astacks[i].print();
        }
        for(i=0;i<m-m/2;i++){
                cout << m/2+i+1 << " ";
                lstacks[i].print();
        }

        return 0;
}