#include "stack_11.h"
//linked list representation of stack derived from base stack class
class lstack: public stack{
        struct node {
	        long long data;
	        struct node* next;
        }; 
        struct node* head;
        long long maxsize;
        long long curr_size;
        node* n;

public:
//stack operations
        lstack(){};
        lstack(long long s);
        ~lstack(){} ;
        void push(long long value);
        void pop();
        void print();
};