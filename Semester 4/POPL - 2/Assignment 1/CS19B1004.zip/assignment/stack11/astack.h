#include "stack_11.h"
//array representation of stack derived from base stack class
class astack: public stack{
        long long* array;
        long long index;
        long long size;
        
public:
//stack operations
        astack(){};
        astack(long long s);
        ~astack(){}; 
        void push(long long value);
        void pop();
        void print();
};