#ifndef STACK_H
#define STACK_H
//stack interface, stack.h

//abstract base stack class with virtual functions
class stack {
public: 
        stack(){};
        stack(long long s);
        virtual void push(long long value) = 0;
        virtual void pop() = 0;
        virtual void print() = 0;
        ~stack(){};
};

#endif