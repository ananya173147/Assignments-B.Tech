#include"stack_15.h"
#include <iostream>
#include <cstdlib>
using namespace std;

//rep functions implementation
rep::rep(){
        arr = (long long*)malloc(sizeof(long long)*10000);
        index = -1;
        size = 10000;
}

void rep::push(long long v){
        index++;
        arr[index] = v;
}

void rep::pop(){
        if(index==-1)
                return;
        index--;
}

void rep::print(){
        for(long long i=index;i>=0;i--){
                cout << arr[i] << " ";
        }
        cout << endl;
}

void rep::destroy(){
        free(arr);
}

//operator to select the stack function
long long cat_object::operator()(int oper, long long arg){
for(oper_link* pp = oper_table; pp; pp= pp->next)
        if(oper == pp->oper) return pp->fct(p,arg);
        return arg;
}

//function to add new stack operation to list of operations
void cat_object::add_oper(int oper_1, PcatF fct_1){
        oper_link *p1 = new oper_link(oper_1,fct_1,oper_table);
        p1->next = oper_table;
        oper_table = p1;
}

//function to remove stack operation from list of operations
void cat_object::remove_oper(int oper_1){
        for(oper_link* pp = oper_table; pp; pp= pp->next)
                if( oper_1 == pp->oper){
                        oper_link* temp = pp;
                        pp = pp->next;
                        delete(temp); 
                }
}

//functions to push forward stack operations
static long long stack_push_fct(void* p, long long c){
        ((rep*) p)->push(c);
        return c;
}

static long long stack_pop_fct(void* p, long long c){
        ((rep*) p)->pop();
        return c;
}

static long long stack_destroy_fct(void* p, long long c){
        ((rep*) p)->destroy();
        return c;
}

static long long stack_print_fct(void* p, long long c){
        ((rep*) p)->print();
        return c;
}

//creating cat object and adding stack operations
cat_object* make_stack(cat_object* p)
{
        if(p == 0)
                p = new cat_object(0, new rep) ;        // get a clean object and make it behave like a stack
        
        p->add_oper(stack_push, &stack_push_fct) ;      
        p->add_oper(stack_pop, &stack_pop_fct) ;        
        p->add_oper(stack_destroy, &stack_destroy_fct) ;
        p->add_oper(stack_print,&stack_print_fct);
        
return p;
}