#include <iostream>
#include <cstdlib>
#include "stack_15.h"
//method 15

using namespace std;

int main(){
        long long m,n,i,p,q;
        string s;
        cin >> m >> n;
//array of cat objects
        cat_object stacks[m];

        for(i=0;i<m;i++){
//creating and initialising stack data members
               stacks[i] = *make_stack();
        }
        i=0;
        while(i<n){
                cin >> p >> s;
                if(s=="push"){
                        cin >> q;
                        stacks[p-1](stack_push,q);
                }
                else if(s=="pop"){
                        stacks[p-1](stack_pop,p);
                }
                i++;   
        }

        for(i=0;i<m;i++){
                cout << i+1 << " ";
                stacks[i](stack_print,m);                
                stacks[i](stack_destroy,m);
        }

        return 0;
}