#ifndef STACK_H
#define STACK_H

// primitive building block: lists of (operation_identifier,function) pairs
typedef long long (*PcatF)(void*,long long);

//Using oper_links we can specify a class cat_object that allows us to invoke an unspecified set of functions on an unspecified representation
struct oper_link{
        oper_link* next;
        int oper;
        PcatF fct;
        oper_link(int oo, PcatF ff, oper_link* nn)
                : oper(oo), fct(ff), next(nn) {}
};

//rep to hold stack representation and operations
struct rep{
        long long *arr;
        long long index;
        long long size;
        rep();
        void push(long long);
        void pop();
        void print();
        void destroy();
};

//cat_object class
class cat_object{
        void* p;                // pointer to representation
        oper_link* oper_table;  // list of operations
public:
        cat_object(oper_link* tbl = 0, void* rep = 0)
                : oper_table(tbl), p(rep) {}
        long long operator()(int oper, long long arg= 0);
        void add_oper(int, PcatF);
        void remove_oper(int);
};

//enum to store operation types
enum stack_oper{stack_destroy = 99, stack_push, stack_pop, stack_print};

//default parameter to create cat object
cat_object* make_stack(cat_object* = 0) ;

#endif